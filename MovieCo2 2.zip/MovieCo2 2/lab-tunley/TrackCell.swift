//
//  TrackCell.swift
//  lab-tunley
//
//  Created by Trevor Simpson on 2/4/24.
//

import UIKit
import Nuke

class TrackCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    @IBOutlet weak var trackNameLabel: UILabel!
    @IBOutlet weak var artistNameLabel: UILabel!
    @IBOutlet weak var trackImageView: UIImageView!
    
    /// Configures the cell's UI for the given track.
    func configure(with track: Track) {
        trackNameLabel.text = track.title
        artistNameLabel.text = track.overview
        
       
        let imageUrl = URL(string:"https://image.tmdb.org/t/p/w500" + track.poster_path)!
        Nuke.loadImage(with: imageUrl, into: trackImageView)
        //https://image.tmdb.org/t/p/w500/{posterPath}
    }
}
