//
//  Posters.swift
//  MovieCo
//
//  Created by Arely Correa on 2/13/24.
//

import Foundation

struct PostersSearchResponse: Decodable {
    let results: [Posters]
    
}

struct Posters: Decodable {
    let poster_path: String
    let title: String
    let overview: String
    let vote_average: Double
    let popularity: Double
    let vote_count: Int
}


