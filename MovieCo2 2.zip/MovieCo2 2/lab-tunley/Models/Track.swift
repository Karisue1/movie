//
//  Track.swift
//  lab-tunley
//
//  Created by Charlie Hieger on 12/2/22.
//

import Foundation

// TODO: Pt 1 - Create a Track model struct
struct Track: Decodable{
    let title: String
    let overview: String
    let poster_path: String
    let vote_average: Double
    let popularity: Double
    let vote_count: Int
    //let trackTimeMillis: Int
    
    
}

struct MovieResponse: Decodable {
    let page:Int
    let results:[Track]
}

//extension Track{
//    /// An array of mock tracks
//    /// An array of mock tracks
//    static var mockTracks: [Track]  = [
//        Track(title: "Sixty Minutes",//Movie name
//              overview: "Desperate to keep custody of his daughter, a mixed martial arts fighter abandons a big match and races across Berlin to attend her birthday party.",//Description
//              poster_path: URL(string:"https://m.media-amazon.com/images/M/MV5BZDIxY2Y2YzQtZjgwNy00YTAzLWE2NDYtYzU5ZjEyMTI4ZTg5XkEyXkFqcGdeQXVyMTEzMTI1Mjk3._V1_.jpg")!,//Photo
//             vote_average: 6.939,//Average vote
//             popularity: 1041.037,//Popularity
//              vote_count: 1//votes
//              ),
//        Track(title: "Aquaman and the Lost Kingdom",
//              overview: "Still driven by the need to avenge his father's death and wielding the power of the mythic Black Trident, will stop at nothing to take Aquaman down once and for all. To defeat him, Aquaman must turn to his imprisoned brother Orm, the former King of Atlantis, to forge an unlikely alliance in order to save the world from irreversible destruction",
//              poster_path: URL(string: "https://s3-ap-southeast-2.amazonaws.com/yc.cldmlk.com/1000000008/1702002682204_HO00001194.jpeg")!,
//              vote_average: 6.997,
//              popularity: 1831.771,
//              vote_count: 2//2021-05-14T12:00:00Z
//               ),
//        Track(title: "Oppenheimer",
//              overview: "The story of J. Robert Oppenheimer's role in the development of the atomic bomb during World War II.",
//              poster_path: URL(string: "https://s.yimg.com/ny/api/res/1.2/3JJRZ7O.qYDi5ik1oyrifw--/YXBwaWQ9aGlnaGxhbmRlcjt3PTY0MDtoPTg2Ng--/https://media.zenfs.com/en/total_film_411/0d0f15ca12a964b2143a9a40fea27741")!,
//              vote_average: 8.117,
//              popularity: 467.049,
//               vote_count: 3//1997-03-01T08:00:00Z
//               ),
//        Track(title: "The Bricklayer",
//              overview: "Someone is blackmailing the CIA by assassinating foreign journalists and making it look like the agency is responsible. As the world begins to unite against the U.S., the CIA must lure its most brilliant – and rebellious – operative out of retirement, forcing him to confront his checkered past while unraveling an international conspiracy.",
//              poster_path: URL(string: "https://media.themoviedb.org/t/p/w500/pwOQ9lqLX1OgsJRSybS662wMcu8.jpg")!,
//              vote_average: 6.164,
//              popularity: 332.084,
//               vote_count: 4//1997-03-01T08:00:00Z
//               ),
//        Track(title: "Migration",
//              overview: "After a migrating duck family alights on their pond with thrilling tales of far-flung places, the Mallard family embarks on a family road trip, from New England, to New York City, to tropical Jamaica.",
//              poster_path: URL(string: "https://universalpictures.ca/wp-content/uploads/2023/08/migration_Poster_1920x826-1-2.jpg")!,
//              vote_average: 7.743,
//              popularity: 1736.027,
//               vote_count: 5//1997-03-01T08:00:00Z
//               )
//    ]
//    
//
//        // We can now access this array of mock tracks anywhere like this:
//        // let tracks = Tracks.mockTracks
//}


// TODO: Pt 1 - Create an extension with a mock tracks static var


// MARK: Helper Methods
/// Converts milliseconds to mm:ss format
///  ex:  208643 -> "3:28"
///  ex:
func formattedTrackDuration(with milliseconds: Int) -> String {
    let (minutes, seconds) = milliseconds.quotientAndRemainder(dividingBy: 60 * 1000)
    let truncatedSeconds = seconds / 1000
    if truncatedSeconds >= 10 {
        return "\(minutes):\(truncatedSeconds)"
    } else {
        return "\(minutes):0\(truncatedSeconds)"
    }
}
